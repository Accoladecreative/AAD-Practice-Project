package com.example.aad_phase_2_practice_project.model

data class SkillIQLeadersEntity(
    var name : String,
    var score : Int,
    var country : String,
    var badgeUrl : String
)
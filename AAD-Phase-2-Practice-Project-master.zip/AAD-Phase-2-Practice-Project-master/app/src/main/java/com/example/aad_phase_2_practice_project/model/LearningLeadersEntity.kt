package com.example.aad_phase_2_practice_project.model

data class LearningLeadersEntity(
    var name : String,
    var hours : Int,
    var country : String,
    var badgeUrl : String
)